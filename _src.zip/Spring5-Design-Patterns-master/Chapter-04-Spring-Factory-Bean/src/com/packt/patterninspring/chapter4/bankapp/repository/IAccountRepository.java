package com.packt.patterninspring.chapter4.bankapp.repository;

public interface IAccountRepository {

}
