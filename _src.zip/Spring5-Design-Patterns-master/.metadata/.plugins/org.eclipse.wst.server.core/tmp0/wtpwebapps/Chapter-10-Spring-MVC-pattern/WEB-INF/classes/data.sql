INSERT INTO ACCOUNT (id, name, balance) values (1000, 'Dinesh', 20000);
INSERT INTO ACCOUNT (id, name, balance) values (2000, 'Arnav', 40000);
INSERT INTO ACCOUNT (id, name, balance) values (3000, 'Anamika', 60000);