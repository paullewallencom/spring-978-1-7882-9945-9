package com.packt.patterninspring.chapter2.model;

public interface Account {
	
	void accountType();
}
