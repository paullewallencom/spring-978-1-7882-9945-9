package com.packt.patterninspring.chapter2.adapter.pattern;

public interface AdvancedPayGateway {
	
	void makePayment(String mobile1, String mobile2);
	
}
