package com.packt.patterninspring.chapter2.facade.pattern;

public interface BankingServiceFacade {
	void moneyTransfer();
}
