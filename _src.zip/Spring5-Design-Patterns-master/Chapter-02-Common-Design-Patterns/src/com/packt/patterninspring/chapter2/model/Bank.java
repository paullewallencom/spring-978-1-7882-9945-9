package com.packt.patterninspring.chapter2.model;

public interface Bank {
	void bankName();
}
