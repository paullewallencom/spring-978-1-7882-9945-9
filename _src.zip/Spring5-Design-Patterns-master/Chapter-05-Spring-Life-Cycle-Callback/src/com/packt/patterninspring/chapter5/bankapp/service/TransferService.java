package com.packt.patterninspring.chapter5.bankapp.service;

import org.springframework.stereotype.Service;

/**
 * @author Dinesh Rajput
 *
 */
@Service
public class TransferService {

}
