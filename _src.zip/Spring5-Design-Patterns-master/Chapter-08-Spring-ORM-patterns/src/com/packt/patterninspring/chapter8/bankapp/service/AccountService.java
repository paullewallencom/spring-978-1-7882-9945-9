package com.packt.patterninspring.chapter8.bankapp.service;

import com.packt.patterninspring.chapter8.bankapp.model.Account;

/**
 * @author Dinesh.Rajput
 *
 */
public interface AccountService {
	Double cheeckAccountBalance(Account account);
}
